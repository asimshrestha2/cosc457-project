public class SessionData {
	public String username = "";
	public String userType = "";
	public String asdf = "";
}
