
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class MenuGUI extends JFrame implements ActionListener{
    
    	DBConnection dbconnection = new DBConnection();

    public MenuGUI() {
         super("Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Menu");
        add(new JLabel("Annie's Menu!!!!"));
        pack();
        setVisible(true);
        
        
                JButton backBtn = new JButton("Back");
		backBtn.addActionListener(this);
		backBtn.setActionCommand("backback");
		
		//listPane.add(backBtn);
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
