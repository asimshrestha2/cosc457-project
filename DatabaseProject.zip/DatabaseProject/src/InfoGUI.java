import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class InfoGUI extends JFrame implements ActionListener {

    JLabel errorL;
    
private JTextField emailText;
    public InfoGUI() {
        super("Info");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel listPane = new JPanel();
        
        listPane.setBackground(Color.red.darker());

        
        //listPane.setLayout(new BoxLayout(listPane, BoxLayout.Y_AXIS));
        
                JPanel textFieldPanel = new JPanel();
                		
                String text = "<html> <bold> <center> <H2> <U> Hours of Operation </U> </H2>"
                        + "<P>Monday: 11:00 am - 10:00 pm</P>"
                        + "<P>Tuesday: 11:00 am - 10:00 pm</P>"
                        + "<P>Wendsday: 11:00 am - 10:00 pm</P>"
                        + "<P>Thursday: 11:00 am - 10:00 pm</P>"
                        + "<P>Friday: 11:00 am - 10:00 pm</P>"
                        + "<P>Saturday: 11:00 am - 10:00 pm</P>"
                        + "<P>Sunday: 11:00 am - 10:00 pm</P>"
                        + "<P> </P>"
                        + "<P> </P>"
                        + "<P> </P>"
                        + " <H2> <U>Locations</U> </H2>"
                        + "<P>500 Kent Narrow Way N,</P>"
                        + "<P>Grasonville, MD 21638</P>"
                        + "<P> </P>"
                        + "<P> 1609 17th St. NW,</P>"
                        + "<P>Washington DS 20009</P>"
                        + "<P> </P>"
                        + "<P> </P>"
                        + "<P> </P>"
                        + " <H2> <U>Contact Information</U> </H2>"
                        + "<P>Phone: 410-827-7103 (Grasonville Location)</P>"
                        + "<P>Phone: 202-232-0395 (DC Location)</P>"
                        + "<P> Fax: 410-827-6715 (Grasonville Location) </P>"
                        + "Email: info@annies.biz</P>"
                        + "<P> </P>"
                        + "<P> </P>"
                        + "<P> </P>"
                        + " <H2> <U>Annie's Team</U> </H2>"
                        + "<P>Owners: Michael & Helen Katinas</P>"
                        + "<P>General Manager: Georgeanne McCreary</P>"
                        + "<P>Executive Chef: Brett Wingard</P>"
                        + "<P>Head Chef: Kurt Lentzsch</P>"
                        + "</center> </bold> </html>";
                JLabel informationBox = new JLabel(text);
                
                textFieldPanel.setBackground(Color.red.darker());
		textFieldPanel.add(informationBox);

        setTitle("Information ");
        pack();
        setVisible(true);
        
        
         JButton backBtn = new JButton("Back" );
         JPanel btnPanel = new JPanel(new BorderLayout());
        
        
        btnPanel.setBackground(Color.red.darker());
        btnPanel.add(backBtn);
                
                
	backBtn.addActionListener(this);
	backBtn.setActionCommand("backback");
                        //textFieldPanel.add(btnPanel);
                        
                                //add(textFieldPanel, BorderLayout.CENTER);



        listPane.add(btnPanel);
        listPane.add(textFieldPanel);		
        add(listPane);	
	pack();
        setVisible(true);
        
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        
    
		String cmd = ae.getActionCommand();
		System.out.println(cmd);
		if(cmd.equals("backback")){
                    
                }
    }
    
}
